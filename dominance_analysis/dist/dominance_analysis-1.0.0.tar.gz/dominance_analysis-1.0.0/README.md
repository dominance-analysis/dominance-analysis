Dominance Analysis Package

This package can be used for dominance analysis on the given data-set.

Please follow the github repository for detailed description [here](https://github.com/bhagatsajan0073/dominance_analysis).