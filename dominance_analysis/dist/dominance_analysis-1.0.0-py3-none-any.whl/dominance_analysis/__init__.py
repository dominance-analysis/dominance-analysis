from dominance_analysis.dominance import *

def test_package_function():
	return "Dominance Analysis Package"
